//
// Created by Sergio Daniel Hernandez on 12/3/17.
//
//=======================================================================
/** @file StandardFilter.h
 *  @author Didier Bieler && Sergio Hernandez
 *
 * This file is part of the project of Sound Processing
 *
 *
 * This class defines a standard filter in the spatial domain.
 *
 */
//=======================================================================
#include "LinearFilter.h"
#include "StandardFilter.cpp"

LinearFilter::LinearFilter() : StandardFilter()
{
    length=5;
    mask = std::vector<double>(length);
}

LinearFilter::LinearFilter(int pLength) : StandardFilter(pLength)
{
    //Checks if the length is even
    if(pLength % 2 == 0){
        throw FilterSizeException();
    }
    length=pLength;
    mask = std::vector<double>(pLength);
    name = "Standard Linear Filter";
}


std::vector<double> LinearFilter::applySamples(std::vector<double> pSignal)
{
    //@todo Verify that the mirror boundary conditions are correct
    //@todo Use some of the new C++ features here (for_each, iota, etc...)
    //@todo verify if no recursion can be done as a standard manner.
    int n = pSignal.size();
    std::vector<double> outputSignal = std::vector<double>(n);
    int l0 = (length -1)/2;
    for (int i = 0; i < n; ++i) {
        double outputValue = 0;
        for (int j = -l0; j <= l0; ++j) {
            int index = j+i;
            if(index < 0){
                index = - index;
            }
            if(index > (n-1)){
                index = 2*(n-1) - index;
            }
            outputValue = outputValue + mask[j+l0]*pSignal[index];
        }
        outputSignal[i] = outputValue;
    }
    return outputSignal;
}


