//
// Created by shernand on 12/7/17.
//
//=======================================================================
/** @file PrewittFilter.h
 *  @author Didier Bieler && Sergio Hernandez
 *
 * This file is part of the project of Sound Processing
 *
 *
 * This class defines a prewitt edge detection filter in the spatial domain.
 *
 */
//=======================================================================
#include "PrewittFilter.h"
PrewittFilter::PrewittFilter() : LinearFilter()
{
    length=5;
    name="Prewitt Filter (band pass)";
    mask = std::vector<double>(length);
    //Fills the mask
    int half = length/2;
    for(int i = 0; i<=half;i++){
        mask[i] = half - i;
        mask[length-1-i] = -(half - i);
    }
    mask[half]=0;
}
PrewittFilter::PrewittFilter(int pLength) : LinearFilter(pLength)
{
    length=pLength;
    name="Prewitt Filter (band pass)";
    mask = std::vector<double>(pLength);
    int half = pLength/2;
    for(int i = 0; i<=half;i++){
        mask[i] = pLength - 2 * half +i;
        mask[pLength-1-i] = -(pLength - 2 * half+i);
    }
    mask[half]=0;
}