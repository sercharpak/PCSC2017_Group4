//
// Created by Sergio Daniel Hernandez on 12/3/17.
//
//=======================================================================
/** @file StandardFilter.h
 *  @author Didier Bieler && Sergio Hernandez
 *
 * This file is part of the project of Sound Processing
 *
 *
 * This class defines a standard linear filter in the spatial domain.
 *
 */
//=======================================================================
#ifndef LINEARFILTER_H
#define LINEARFILTER_H
/** Class which defines a standard filter in the spatial domain.
 */
#include <math.h>
#include <string>
#include <vector>
#include "Signal.h"
#include "StandardFilter.h"
#include "FilterSizeException.hpp"
//template <class T>
class LinearFilter : public StandardFilter{
public:
    /** Standard Constructor
     * The length is set to 5
     */
    LinearFilter();
    /** Constructor with the length of the mask
     * @param pLength int which indicated the length of the filter
     */
    LinearFilter(int pLength);

    /** Applies the filter to the raw data of a signal
     * It is virtual as it can change between linear filters and non linear filters
     * @param std::vector<T> the raw data to which we want to apply the filter.
     * @return std::vector<T> the raw data filtered
     */
    std::vector<double> applySamples(std::vector<double> pSignal) override;

};


#endif //LINEARFILTER_H
