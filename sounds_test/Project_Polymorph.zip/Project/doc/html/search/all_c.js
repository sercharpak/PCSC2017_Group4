var searchData=
[
  ['samples',['samples',['../class_audio_file.html#af937119db095c5af870851050dcbeabb',1,'AudioFile']]],
  ['save',['save',['../class_audio_file.html#a415239cad5b54b4fef4a210ab79911e3',1,'AudioFile']]],
  ['savesignal',['SaveSignal',['../class_signal.html#a48b0a197a97ceb1bcdfff55131049df7',1,'Signal']]],
  ['setaudiobuffer',['setAudioBuffer',['../class_audio_file.html#afa0a0f7d576b0597c938c5a89746636e',1,'AudioFile']]],
  ['setaudiobuffersize',['setAudioBufferSize',['../class_audio_file.html#ac155ed12db0f3b02011a7d75b525e71a',1,'AudioFile']]],
  ['setbitdepth',['setBitDepth',['../class_audio_file.html#a2adf2ea23e7daeb8401e717c1b3d874b',1,'AudioFile']]],
  ['setdata',['setData',['../class_config_file_parser.html#afcf073980b43e48aa2c9af6803412544',1,'ConfigFileParser']]],
  ['setfilternames',['setFilterNames',['../class_config_file_parser.html#a7912e162d84f68b8ccdb173bbbec2c6d',1,'ConfigFileParser']]],
  ['setlength',['setLength',['../class_standard_filter.html#af441d21022cd441f08421de8cd714d53',1,'StandardFilter']]],
  ['setmask',['setMask',['../class_standard_filter.html#abef27f90eea94d34607e24dd026a281e',1,'StandardFilter']]],
  ['setname',['setName',['../class_standard_filter.html#ade80373fc8d38fe8ef568287c69d2faf',1,'StandardFilter']]],
  ['setnumchannels',['setNumChannels',['../class_audio_file.html#a354018a94ae15907d7308782f2adadbb',1,'AudioFile']]],
  ['setnumsamplesperchannel',['setNumSamplesPerChannel',['../class_audio_file.html#a4cff9513d49e21d25de13513564784b7',1,'AudioFile']]],
  ['setsamplerate',['setSampleRate',['../class_audio_file.html#a2d8fa306e40535113c3eba111e16483b',1,'AudioFile']]],
  ['signal',['Signal',['../class_signal.html',1,'Signal'],['../class_signal.html#abbdb0fbc1937ed0344e5f579addca43f',1,'Signal::Signal()=default'],['../class_signal.html#ae86ad0c1a57cbda6baaf953520deaadb',1,'Signal::Signal(AudioFile&lt; double &gt; audio)'],['../class_signal.html#aa3c21568ba4e96fafff037e07f1d7ece',1,'Signal::Signal(std::vector&lt; double &gt; sam)']]],
  ['signal_2ecpp',['Signal.cpp',['../_signal_8cpp.html',1,'']]],
  ['signal_2eh',['Signal.h',['../_signal_8h.html',1,'']]],
  ['standardfilter',['StandardFilter',['../class_standard_filter.html',1,'StandardFilter&lt; T &gt;'],['../class_standard_filter.html#a7ccdce74856a1bdfa877bcec14b5c98b',1,'StandardFilter::StandardFilter()'],['../class_standard_filter.html#acbc237007e90073c4306e748d73d7eaf',1,'StandardFilter::StandardFilter(int pLength)'],['../class_standard_filter.html#a380828493a181b61010bb633538b0e7c',1,'StandardFilter::StandardFilter(std::vector&lt; T &gt; pMask)']]],
  ['standardfilter_2eh',['StandardFilter.h',['../_standard_filter_8h.html',1,'']]]
];
