var searchData=
[
  ['prewittfilter',['PrewittFilter',['../class_prewitt_filter.html',1,'']]]
];
