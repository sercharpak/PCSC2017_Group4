var searchData=
[
  ['laplacefilter',['LaplaceFilter',['../class_laplace_filter.html',1,'']]]
];
