var searchData=
[
  ['apply',['apply',['../class_standard_filter.html#a2b6a11ed970216b26bda63857d4ed1fc',1,'StandardFilter::apply(std::vector&lt; T &gt; pSignal)'],['../class_standard_filter.html#aaebab54027c0cff78fcc8429d91e6fcf',1,'StandardFilter::apply(Signal pSignal)']]],
  ['audiofile',['AudioFile',['../class_audio_file.html#ae74399e93d3f4623c7421ee10cfc0e15',1,'AudioFile']]]
];
