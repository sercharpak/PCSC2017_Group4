var searchData=
[
  ['n_5fargs',['N_ARGS',['../main_8cpp.html#a45427030a543a1fe5b6a6ad24b0415a5',1,'main.cpp']]],
  ['name',['name',['../class_standard_filter.html#a0cf232a923b17ca0b1502538222bcc67',1,'StandardFilter']]]
];
