var searchData=
[
  ['laplacefilter_2eh',['LaplaceFilter.h',['../_laplace_filter_8h.html',1,'']]]
];
