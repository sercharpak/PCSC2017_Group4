var searchData=
[
  ['meanfilter',['MeanFilter',['../class_mean_filter.html',1,'']]]
];
