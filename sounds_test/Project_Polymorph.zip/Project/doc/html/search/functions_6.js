var searchData=
[
  ['inversefouriertransform',['InverseFourierTransform',['../class_signal.html#a3407d4496d7dcde62e64829f0a51092d',1,'Signal']]],
  ['ismono',['isMono',['../class_audio_file.html#a4b268d82202c22b2e8e896531bdcb778',1,'AudioFile']]],
  ['isstereo',['isStereo',['../class_audio_file.html#a87fc46a0062c665a903ddf9c3df7638e',1,'AudioFile']]]
];
