var searchData=
[
  ['name',['name',['../class_standard_filter.html#a0cf232a923b17ca0b1502538222bcc67',1,'StandardFilter']]]
];
