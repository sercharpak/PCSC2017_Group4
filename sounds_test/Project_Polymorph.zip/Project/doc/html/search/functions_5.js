var searchData=
[
  ['histogram',['Histogram',['../class_signal.html#a0f398815b149397885164611bf139c95',1,'Signal']]]
];
