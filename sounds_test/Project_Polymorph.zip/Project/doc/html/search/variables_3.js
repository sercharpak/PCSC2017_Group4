var searchData=
[
  ['samples',['samples',['../class_audio_file.html#af937119db095c5af870851050dcbeabb',1,'AudioFile']]]
];
