//
// Created by Sergio Daniel Hernandez on 12/3/17.
//
//=======================================================================
/** @file StandardFilter.h
 *  @author Didier Bieler && Sergio Hernandez
 *
 * This file is part of the project of Sound Processing
 *
 *
 * This class defines a standard filter in the spatial domain.
 *
 */
//=======================================================================
#include "StandardFilter.h"

StandardFilter::StandardFilter()
{
    length=5;
    mask = std::vector<double>(length);
}

  StandardFilter::StandardFilter(int pLength)
{
    //Checks if the length is even
    /*if(pLength % 2 == 0){
        throw FilterSizeException();
    }
    length=pLength;
    mask = std::vector<double>(pLength);
    name = "Standard Filter";*/
}
  StandardFilter::StandardFilter(std::vector<double> pMask)
{
    mask=pMask;
    length = mask.size();
    name = "Standard Filter";
}


StandardFilter::~StandardFilter(){}


void StandardFilter::setMask(std::vector<double> pMask)
{
    mask=pMask;
}

std::vector<double> StandardFilter::getMask()
{
    return mask;
}


void StandardFilter::setLength(int pLength)
{
    length=pLength;
}

int StandardFilter::getLength()
{
    return length;
}

void StandardFilter::setName(std::string pName)
{
    name=pName;
}

std::string StandardFilter::getName()
{
    return name;
}


std::vector<double> StandardFilter::applySamples(std::vector<double> pSignal)
{

}
Signal StandardFilter::apply(Signal pSignal)
{
    std::vector<double> samples = pSignal.getSamples();
    std::vector<double> outSamples = applySamples(samples);
    Signal outputSignal = Signal(outSamples);
    return outputSignal;
}
