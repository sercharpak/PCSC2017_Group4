//
// Created by shernand on 12/7/17.
//
//=======================================================================
/** @file MedianFilter.h
 *  @author Didier Bieler && Sergio Hernandez
 *
 * This file is part of the project of Sound Processing
 *
 *
 * This class defines a median filter in the spatial domain. Very useful to remove impulse noise.
 *
 */
//=======================================================================
#ifndef PROJECT_MEDIANFILTER_H
#define PROJECT_MEDIANFILTER_H
/** Class which defines a  median filter in the spatial domain.
 * Very useful to remove impulse noise
 */
#include "StandardFilter.h"
#include <vector>
//template <class T>
class MedianFilter : public StandardFilter{
public:
    /** Standard Constructor
     *  The length is set to 5
     *  We compute the median with a 5 sized window.
     */
    MedianFilter();
    /** Constructor with the length of the mask
     *  We compute the median with a 5 sized window.
     * @param pLength int which indicated the length of the filter
     */
    MedianFilter(int pLength);
    /** Applies the filter to the raw data of a signal
     * Computes the median (non linear operation)
     * @param std::vector<T> the raw data to which we want to apply the filter.
     * @return std::vector<T> the raw data filtered
     */
    std::vector<double> applySamples(std::vector<double> pSignal) override;
};


#endif //PROJECT_MEDIANFILTER_Hv
