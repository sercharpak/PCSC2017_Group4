//
// Created by shernand on 12/4/17.
//
//=======================================================================
/** @file MeanFilter.h
 *  @author Didier Bieler && Sergio Hernandez
 *
 * This file is part of the project of Sound Processing
 *
 *
 * This class defines a mean filter in the spatial domain.
 *
 */
//=======================================================================
#include "MeanFilter.h"
MeanFilter::MeanFilter() : LinearFilter()
{
    length=5;
    int pLenght = length;
    name="Mean Filter (low pass)";
    mask = std::vector<double>(length);
    std::for_each(mask.begin(), mask.end(),
                  [&pLenght](double &x) { x = (1.0/ pLenght); }); //Fills the mask
}
MeanFilter::MeanFilter(int pLength) : LinearFilter(pLength)
{
    length=pLength;
    name="Mean Filter (low pass)";
    mask = std::vector<double>(pLength);
    std::for_each(mask.begin(), mask.end(),
                  [&pLength](double &x) { x = (1.0/pLength); }); //Fills the mask
}