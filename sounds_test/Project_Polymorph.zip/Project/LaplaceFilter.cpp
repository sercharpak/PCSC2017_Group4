//
// Created by shernand on 12/8/17.
//
//=======================================================================
/** @file LaplaceFilter.h
 *  @author Didier Bieler && Sergio Hernandez
 *
 * This file is part of the project of Sound Processing
 *
 *
 * This class defines a laplace filter in the spatial domain.
 *
 */
//=======================================================================
#include "LaplaceFilter.h"
LaplaceFilter::LaplaceFilter() : LinearFilter()
{
    length=5;
    name="Laplace Filter (high pass)";
    int pLength = this->length;
    mask = std::vector<double>(length);
    //\todo Find a way to implement the Laplace with iota or foreach
    //Fills the mask
    int half = length/2;
    for(int i = 0; i<=half;i++){
        mask[i] = 1;
        mask[length-1-i] = 1;
    }
    mask[half]=-(length-1);
}
LaplaceFilter::LaplaceFilter(int pLength) : LinearFilter(pLength)
{
    length=pLength;
    name="Laplace Filter (high pass)";
    std::vector<double> mask = std::vector<double>(pLength);
    int half = pLength/2;
    for(int i = 0; i<=half;i++){
        mask[i] = 1;
        mask[pLength-1-i] = 1;
    }
    mask[half]=-(pLength-1);
}